# libros-web

Frontend del **Catálogo de Libros**. Está hecho con Vue 3, Vite, TypeScript y Vue Router.
Se comunica con la API `libros-api` por HTTP y JSON.

## Las tres vistas

| Ruta | Vista | Qué hace | Endpoint que usa |
| --- | --- | --- | --- |
| `/` | `ListaView.vue` | Tabla con título, autor y año. Cada título lleva al detalle | GET `/api/libros` |
| `/libros/:id` | `DetalleView.vue` | Muestra un libro, o un mensaje si no existe | GET `/api/libros/:id` |
| `/nuevo` | `NuevoView.vue` | Formulario para crear un libro; al guardar vuelve a `/` | POST `/api/libros` |

## Estructura

```
libros-web/
├── src/
│   ├── services/api.ts   <- único archivo que conoce la API (usa fetch)
│   ├── views/            <- las tres vistas
│   ├── router/index.ts   <- rutas
│   ├── App.vue           <- menú (RouterLink) y espacio para las vistas
│   └── main.ts
├── .env.development      <- VITE_API_URL para desarrollo
├── .env.production.example
├── .gitignore
└── package.json
```

La dirección de la API **no está escrita en el código**: se lee de la variable `VITE_API_URL`.

## Requisitos

- Node.js 22 y npm
- El backend `libros-api` funcionando en el puerto 3000

## Cómo ejecutarlo en tu computador (modo desarrollo)

1. En otra consola, deja corriendo el backend (`npm run dev` dentro de `libros-api`).
2. En esta carpeta:

```bash
npm install
npm run dev
```

3. Abre http://localhost:5173

## Cómo ejecutarlo en producción (VM lab-front de Google Cloud)

```bash
sudo apt-get install -y nginx
git clone <URL_REPO_WEB>
cd libros-web
echo "VITE_API_URL=http://<IP_BACK>:3000/api" > .env.production
npm ci
npm run build                      # crea la carpeta dist/
sudo mkdir -p /var/www/libros
sudo cp -r dist/* /var/www/libros/
```

Cambia `<IP_BACK>` por la IP externa de la VM del backend.
`VITE_API_URL` se fija al compilar: si cambia la IP del backend, hay que volver a ejecutar `npm run build` y copiar `dist/`.

Reemplaza el contenido de `/etc/nginx/sites-available/default` por:

```nginx
server {
  listen 80;
  root /var/www/libros;
  index index.html;
  location / { try_files $uri $uri/ /index.html; }
}
```

Y reinicia Nginx:

```bash
sudo nginx -t && sudo systemctl restart nginx
```

La línea `try_files` evita el error 404 al recargar `/nuevo` o `/libros/1`.
Luego abre `http://<IP_FRONT>` en el navegador.
