/// <reference types="vite/client" />

// Le dice a TypeScript que existe la variable VITE_API_URL
interface ImportMetaEnv {
  readonly VITE_API_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

// Permite importar archivos .vue desde TypeScript
declare module '*.vue' {
  import type { DefineComponent } from 'vue';
  const componente: DefineComponent<object, object, unknown>;
  export default componente;
}
