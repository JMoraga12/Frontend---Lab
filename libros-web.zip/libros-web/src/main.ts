import { createApp } from 'vue';
import App from './App.vue';
import enrutador from './router';

// Crea la aplicación, le agrega el enrutador y la muestra en <div id="app">
createApp(App).use(enrutador).mount('#app');
