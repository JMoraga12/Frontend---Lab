import { createRouter, createWebHistory } from 'vue-router';
import ListaView from '../views/ListaView.vue';
import DetalleView from '../views/DetalleView.vue';
import NuevoView from '../views/NuevoView.vue';

// Cada ruta (dirección) muestra una vista distinta
const enrutador = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'lista', component: ListaView },
    { path: '/libros/:id', name: 'detalle', component: DetalleView },
    { path: '/nuevo', name: 'nuevo', component: NuevoView },
  ],
});

export default enrutador;
