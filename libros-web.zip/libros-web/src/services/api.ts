// ============================================================
// Servicio de la API: es el ÚNICO archivo que conoce el backend.
// Las vistas llaman a estas funciones y no usan fetch directamente.
// ============================================================

// Así es cada libro
export interface Libro {
  id: number;
  titulo: string;
  autor: string;
  anio: number;
}

// La URL del backend NO se escribe aquí: viene de la variable VITE_API_URL
// (.env.development en local, .env.production en la VM)
const URL_API = import.meta.env.VITE_API_URL;

// GET /api/libros -> lista de libros
export async function obtenerLibros(): Promise<Libro[]> {
  const respuesta = await fetch(`${URL_API}/libros`);
  if (!respuesta.ok) {
    throw new Error(`Error ${respuesta.status}`);
  }
  return respuesta.json();
}

// GET /api/libros/:id -> un libro, o null si no existe
export async function obtenerLibro(id: number): Promise<Libro | null> {
  const respuesta = await fetch(`${URL_API}/libros/${id}`);
  if (!respuesta.ok) {
    return null;
  }
  return respuesta.json();
}

// POST /api/libros -> crea un libro (el id lo asigna el backend)
export async function crearLibro(libro: Omit<Libro, 'id'>): Promise<Libro> {
  const respuesta = await fetch(`${URL_API}/libros`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(libro),
  });
  if (!respuesta.ok) {
    throw new Error(`Error ${respuesta.status}`);
  }
  return respuesta.json();
}
