<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { RouterLink, useRoute } from 'vue-router';
import { obtenerLibro, type Libro } from '../services/api';

const rutaActual = useRoute();
const libro = ref<Libro | null>(null);
const cargando = ref(true);
const mensajeError = ref('');

// Al aparecer la vista, pide a la API el libro cuyo id viene en la dirección (/libros/:id)
onMounted(async () => {
  try {
    libro.value = await obtenerLibro(Number(rutaActual.params.id));
  } catch {
    mensajeError.value = 'No se pudo conectar con la API.';
  } finally {
    cargando.value = false;
  }
});
</script>

<template>
  <h2>Detalle del libro</h2>

  <p v-if="cargando">Cargando...</p>
  <p v-else-if="mensajeError" class="error">{{ mensajeError }}</p>
  <p v-else-if="!libro" class="error">El libro no existe.</p>

  <dl v-else>
    <dt>Título</dt><dd>{{ libro.titulo }}</dd>
    <dt>Autor</dt><dd>{{ libro.autor }}</dd>
    <dt>Año</dt><dd>{{ libro.anio }}</dd>
    <dt>ID</dt><dd>{{ libro.id }}</dd>
  </dl>

  <RouterLink to="/">Volver al listado</RouterLink>
</template>
