<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { RouterLink } from 'vue-router';
import { obtenerLibros, type Libro } from '../services/api';

// Datos que usa la vista
const libros = ref<Libro[]>([]);
const cargando = ref(true);
const mensajeError = ref('');

// Cuando la vista aparece en pantalla, pide los libros a la API
onMounted(async () => {
  try {
    libros.value = await obtenerLibros();
  } catch {
    mensajeError.value = 'No se pudo conectar con la API.';
  } finally {
    cargando.value = false;
  }
});
</script>

<template>
  <h2>Listado de libros</h2>

  <p v-if="cargando">Cargando...</p>
  <p v-else-if="mensajeError" class="error">{{ mensajeError }}</p>

  <table v-else>
    <thead>
      <tr><th>Título</th><th>Autor</th><th>Año</th></tr>
    </thead>
    <tbody>
      <!-- Una fila por libro; el título lleva al detalle -->
      <tr v-for="libro in libros" :key="libro.id">
        <td><RouterLink :to="`/libros/${libro.id}`">{{ libro.titulo }}</RouterLink></td>
        <td>{{ libro.autor }}</td>
        <td>{{ libro.anio }}</td>
      </tr>
    </tbody>
  </table>
</template>
