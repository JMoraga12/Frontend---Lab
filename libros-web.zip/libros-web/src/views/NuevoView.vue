<script setup lang="ts">
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { crearLibro } from '../services/api';

const enrutador = useRouter();

// Datos que escribe la persona en el formulario
const formulario = reactive({
  titulo: '',
  autor: '',
  anio: new Date().getFullYear(),
});
const mensajeError = ref('');

// Se ejecuta al enviar el formulario
async function guardarLibro() {
  mensajeError.value = '';
  try {
    await crearLibro({
      titulo: formulario.titulo,
      autor: formulario.autor,
      anio: Number(formulario.anio),
    });
    // Si se guardó bien, vuelve al listado
    enrutador.push('/');
  } catch {
    mensajeError.value = 'No se pudo guardar el libro.';
  }
}
</script>

<template>
  <h2>Nuevo libro</h2>

  <form @submit.prevent="guardarLibro">
    <label>Título <input v-model="formulario.titulo" required /></label>
    <label>Autor <input v-model="formulario.autor" required /></label>
    <label>Año <input v-model.number="formulario.anio" type="number" required /></label>
    <button type="submit">Guardar</button>
  </form>

  <p v-if="mensajeError" class="error">{{ mensajeError }}</p>
</template>
