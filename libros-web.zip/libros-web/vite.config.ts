import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';

// Configuración de Vite: usa el plugin de Vue y el puerto 5173 en desarrollo
export default defineConfig({
  plugins: [vue()],
  server: { port: 5173, strictPort: true },
});
